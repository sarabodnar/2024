package main;

import java.util.ArrayList;
import modelo.Financiamento;
import util.InterfaceUsuario;

public class Main {
    public static void main (String[]args) {
        //criar uma instância de InterfaceUsuario para ler os dados do usuário
        InterfaceUsuario interfaceUsuario = new InterfaceUsuario();

        //arraylist para armazenar financiamentos
        ArrayList<Financiamento> financiamentos = new ArrayList<>();

        //adicionar os 4 financiamentos
        for (int i = 0; i < 4; i++) {
            System.out.println("Financiamento " + (i + 1));
            double ValorImovel = InterfaceUsuario.PedirValorImovel();
            int PrazoFinanciamento = InterfaceUsuario.PedirPrazoFinanciamento();
            double TaxaJurosAnual = InterfaceUsuario.PedirTaxaJurosAnual();
            Financiamento financiamento = new Financiamento(ValorImovel, PrazoFinanciamento, TaxaJurosAnual);
            financiamentos.add(financiamento);
        }

        //calcular os totais
        double TotalValorImoveis= 0;
        double TotalValorFinanciamentos = 0;

        for (Financiamento financiamento: financiamentos){
            TotalValorImoveis+=financiamento.getValorImovel();
            TotalValorFinanciamentos+= financiamento.CalcularTotalPagamento();
        }


        //ler os dados  do financiamento
        double ValorImovel = interfaceUsuario.PedirValorImovel();
        int PrazoFinanciamento = interfaceUsuario.PedirPrazoFinan();
        double TaxaJurosAnual = interfaceUsuario.PedirTaxadejurosAnual();


        // Exibir os financiamentos e os totais
        for (int i = 0; i < financiamentos.size(); i++) {
            Financiamento financiamento = financiamentos.get(i);
            System.out.println("Financiamento " + (i + 1) + " – valor do imóvel: R$ " + financiamento.getValorImovel() +
                    ", valor do financiamento: R$ " + financiamento.CalcularTotalPagamento());
        }

        System.out.println("Total de todos os imóveis: R$ " + TotalValorImoveis);
        System.out.println("Total de todos os financiamentos: R$ " + TotalValorFinanciamentos);
    }
}


}