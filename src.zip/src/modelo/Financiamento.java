package modelo;

public class Financiamento {
    private double ValorImovel;
    private int PrazoFinanciamento;
    private double TaxaJurosAnual;

    public Financiamento(double ValorImovel, int PrazoFinanciamento, double TaxaJurosAnual){
        this.ValorImovel = ValorImovel;
        this.PrazoFinanciamento= PrazoFinanciamento;
        this.TaxaJurosAnual= TaxaJurosAnual;
    }
    //Métodos getter
    public double getValorImovel(){
        return ValorImovel;
    }
    public int getPrazoFinanciamento(){
        return PrazoFinanciamento;
    }
    public double getTaxaJurosAnual(){
        return TaxaJurosAnual;
    }
    //método para cálculo do pagamento mensalv
    public double CalcularPagMensal(){
        double TaxaMensal= TaxaJurosAnual /12/100;
        int PrazoMeses= PrazoFinanciamento *12;
        return (ValorImovel/ PrazoMeses) * (1+ TaxaMensal);
    }
    //MÉTODO PARA CÁLCULO TOTAL DO PAGAMENTO
    public double CalcularTotalPagamento(){
        return CalcularPagMensal() * PrazoFinanciamento * 12;
    }
    //Método para exibir os dados do financiamento
    public void ExibirDadosFinanciamento(){
        System.out.println("Valor do Imóvel:"+ValorImovel);
        System.out.println ("Prazo do Financiamento: "+ PrazoFinanciamento+ "Anos");
        System.out.println ("Taxa de Juros Anual: "+ TaxaJurosAnual+"%");
        System.out.println ("Pagamento Mensal: "+CalcularPagMensal());
        System.out.println ("Total Paamento: "+ CalcularTotalPagamento());
    }
}
