package util;

import java.util.Scanner;

public class InterfaceUsuario {
    private Scanner scanner;

    public InterfaceUsuario(){
        scanner = new Scanner(System.in);
    }
    //Método para pedir o valor do imóvel
    public double PedirValorImovel() {
        double ValorImovel;
        do {
            System.out.print("Digite o valor do imóvel:");
            ValorImovel = scanner.nextDouble();
            if (ValorImovel <= 0) {
                System.out.println("O valor do imóvel deve ser positivo!: ");
            }
        } while (ValorImovel <= 0);
        return ValorImovel;
    }
    //Método para medir o financiamento
    public int PedirPrazoFinan(){
        int PrazoFinanciamento;

        do {
            System.out.print("Digite o prazo em anos para o financimento: ");
            PrazoFinanciamento= scanner.nextInt();
            if (PrazoFinanciamento <= 0) {
                System.out.println("Prazo do fincanciamento deve ser positivo.");
            }
        } while (PrazoFinanciamento<=0);
        return PrazoFinanciamento;
    }

    //Método taxa de juros anual
    public double PedirTaxadejurosAnual(){
        double taxa;
        do {
            System.out.print("Digite a taxa  de juros anual:  ");
            taxa = scanner.nextDouble();
            if (taxa <= 0) {
                System.out.println("A taxa de juros atual deve ser positiva.");
            }
        }while (taxa<=0);
        return taxa;

    }
}

